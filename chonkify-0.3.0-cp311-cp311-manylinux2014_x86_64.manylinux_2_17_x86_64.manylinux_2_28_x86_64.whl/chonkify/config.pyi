from typing import Mapping


class AzureEmbeddingConfig:
    endpoint: str
    api_key: str
    api_version: str
    deployment: str
    model_label: str
    dimensions: int
    max_batch_size: int
    timeout_seconds: float

    def __init__(
        self,
        endpoint: str,
        api_key: str,
        api_version: str,
        deployment: str,
        model_label: str = ...,
        dimensions: int = ...,
        max_batch_size: int = ...,
        timeout_seconds: float = ...,
    ) -> None: ...


def azure_embedding_config_from_env(
    *,
    endpoint: str | None = ...,
    api_key: str | None = ...,
    api_version: str | None = ...,
    deployment: str | None = ...,
    model_label: str | None = ...,
    max_batch_size: int = ...,
    timeout_seconds: float = ...,
    env: Mapping[str, str] | None = ...,
) -> AzureEmbeddingConfig: ...
