from typing import Sequence

from chonkify.config import AzureEmbeddingConfig
from chonkify.types import CompressionRequest, CompressionResult, Document, EmbeddingProvider


class AzureOpenAIEmbeddingProvider:
    name: str

    def __init__(self, config: AzureEmbeddingConfig) -> None: ...
    def embed_texts(self, texts: Sequence[str]) -> list[list[float]]: ...


def compress_documents(
    documents: Sequence[Document],
    request: CompressionRequest,
    provider: EmbeddingProvider,
) -> CompressionResult: ...
